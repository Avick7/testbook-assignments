var quoteSource = [{
    quote: "You have to write the book that wants to be written. And if the book will be too difficult for grown-ups, then you write it for children.",
    name: "Madeleine L'Engle"
},
{
    quote: "We write to taste life twice, in the moment and in retrospect.",
    name: "Anaïs Nint"
},
{
    quote: "If there's a book that you want to read, but it hasn't been written yet, then you must write it.",
    name: "mark twain"
},
{
    quote: "No tears in the writer, no tears in the reader. No surprise in the writer, no surprise in the reader.",
    name: "Robert frost"
},
{
    quote:
        "How vain it is to sit down to write when you have not stood up to live.",
    name: "Henry David Thoreau"
}];
constquoteButton = document.getElementById('quoteButton');
function myfunction() {
    //getting a new random number to attach to a quote and setting a limit 
    var sourceLength = quoteSource.length;
    var randomNumber = Math.floor(Math.random() * sourceLength);
    //set a new quote 
    var newQuoteText = quoteSource[randomNumber].quote;
    var newQuoteGenius = quoteSource[randomNumber].name;
    var quoteContainer = document.getElementById('quoteContainer');
    quoteContainer.innerHTML =`<p>${newQuoteText}</p> <p id ="quoteGenius">-${newQuoteGenius} </p>`;

}
